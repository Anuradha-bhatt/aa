# Study planner (Firebase)

Email se sign in, study tasks add karo, pending / completed mark karo.

- Frontend: HTML, CSS, JavaScript
- Backend + database: Firebase (Authentication + Cloud Firestore)

## Setup (ek baar)

1. https://console.firebase.google.com par naya project banao.
2. Build > Authentication > Get started > Sign-in method > **Email/Password** ko Enable karo.
3. Build > Firestore Database > Create database (test mode ya production mode, dono chalega).
4. Firestore > Rules tab mein `firestore.rules` ka content paste karke **Publish** karo.
5. Project settings (gear icon) > General > Your apps > Web (`</>`) > app register karo.
   Jo `firebaseConfig` mile use `firebase-config.js` mein paste karo.

## Run

VS Code mein Live Server extension se `index.html` pe **Go Live** karo.
(File ko double-click karke mat kholna: `file://` pe Firebase modules load nahi hote.)

## Files

    index.html         page structure
    style.css          look and feel
    app.js             sign in, tasks, Firebase calls
    firebase-config.js tumhara Firebase config
    firestore.rules    security rules (har user ko sirf apna data)
