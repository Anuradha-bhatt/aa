import { initializeApp } from "https://www.gstatic.com/firebasejs/10.14.1/firebase-app.js";
import {
  getAuth,
  onAuthStateChanged,
  createUserWithEmailAndPassword,
  signInWithEmailAndPassword,
  signOut,
} from "https://www.gstatic.com/firebasejs/10.14.1/firebase-auth.js";
import {
  getFirestore,
  collection,
  addDoc,
  updateDoc,
  deleteDoc,
  doc,
  onSnapshot,
  serverTimestamp,
} from "https://www.gstatic.com/firebasejs/10.14.1/firebase-firestore.js";
import { firebaseConfig } from "./firebase-config.js";

const $ = (id) => document.getElementById(id);
const authView = $("auth-view");
const appView = $("app-view");

let mode = "login";   // "login" or "register"
let filter = "all";   // "all", "pending" or "completed"
let tasks = [];
let currentUser = null;
let unsubscribeTasks = null;

// ---------- Firebase setup ----------
if (firebaseConfig.apiKey.startsWith("PASTE")) {
  $("setup-error").hidden = false;
  throw new Error("firebase-config.js mein firebaseConfig paste karo.");
}
const app = initializeApp(firebaseConfig);
const auth = getAuth(app);
const db = getFirestore(app);

const tasksRef = (uid) => collection(db, "users", uid, "tasks");

// ---------- helpers ----------
const AUTH_ERRORS = {
  "auth/invalid-email": "Enter a valid email address.",
  "auth/missing-password": "Enter your password.",
  "auth/weak-password": "Password must be at least 6 characters.",
  "auth/email-already-in-use": "An account with this email already exists.",
  "auth/invalid-credential": "Email or password is incorrect.",
  "auth/user-not-found": "Email or password is incorrect.",
  "auth/wrong-password": "Email or password is incorrect.",
  "auth/too-many-requests": "Too many attempts. Wait a few minutes and try again.",
  "auth/network-request-failed": "No internet connection. Check your network.",
  "auth/operation-not-allowed": "Email sign-in is off. Turn it on in Firebase Console > Authentication.",
};
const friendly = (err) => AUTH_ERRORS[err.code] || "Something went wrong. Try again.";

function el(tag, className, text) {
  const node = document.createElement(tag);
  if (className) node.className = className;
  if (text !== undefined) node.textContent = text;
  return node;
}

// ---------- views ----------
function showAuth() {
  appView.hidden = true;
  authView.hidden = false;
}
function showApp(user) {
  authView.hidden = true;
  appView.hidden = false;
  $("user-email").textContent = user.email;
}

// ---------- auth ----------
function setMode(next) {
  mode = next;
  const isLogin = next === "login";
  $("tab-login").setAttribute("aria-selected", isLogin);
  $("tab-register").setAttribute("aria-selected", !isLogin);
  $("auth-submit").textContent = isLogin ? "Sign in" : "Create account";
  $("password").autocomplete = isLogin ? "current-password" : "new-password";
  $("password-hint").hidden = isLogin;
  $("auth-error").textContent = "";
}
$("tab-login").addEventListener("click", () => setMode("login"));
$("tab-register").addEventListener("click", () => setMode("register"));

$("auth-form").addEventListener("submit", async (e) => {
  e.preventDefault();
  $("auth-error").textContent = "";
  const email = $("email").value.trim();
  const password = $("password").value;
  if (!email || !password) {
    $("auth-error").textContent = "Enter your email and password.";
    return;
  }
  try {
    if (mode === "login") await signInWithEmailAndPassword(auth, email, password);
    else await createUserWithEmailAndPassword(auth, email, password);
    $("password").value = "";
  } catch (err) {
    $("auth-error").textContent = friendly(err);
  }
});

$("logout").addEventListener("click", () => signOut(auth));

// Firebase batata hai user sign in hai ya nahi (page reload pe bhi)
onAuthStateChanged(auth, (user) => {
  if (unsubscribeTasks) { unsubscribeTasks(); unsubscribeTasks = null; }
  currentUser = user;
  if (!user) {
    tasks = [];
    showAuth();
    return;
  }
  showApp(user);
  // realtime: Firestore mein tasks badalte hi list apne aap update hoti hai
  unsubscribeTasks = onSnapshot(
    tasksRef(user.uid),
    (snap) => {
      tasks = snap.docs.map((d) => ({ id: d.id, ...d.data() }));
      $("task-error").textContent = "";
      render();
    },
    () => { $("task-error").textContent = "Could not load tasks. Check your Firestore rules."; }
  );
});

// ---------- tasks ----------
$("task-form").addEventListener("submit", async (e) => {
  e.preventDefault();
  $("task-error").textContent = "";
  const title = $("task-title").value.trim();
  if (!title) {
    $("task-error").textContent = "Enter a task title.";
    return;
  }
  try {
    await addDoc(tasksRef(currentUser.uid), {
      title,
      subject: $("task-subject").value.trim(),
      dueDate: $("task-due").value || null,
      status: "pending",
      createdAt: serverTimestamp(),
    });
    $("task-form").reset();
    $("task-title").focus();
  } catch (_) {
    $("task-error").textContent = "Could not add the task. Try again.";
  }
});

async function toggleTask(task) {
  const status = task.status === "completed" ? "pending" : "completed";
  try {
    await updateDoc(doc(db, "users", currentUser.uid, "tasks", task.id), { status });
  } catch (_) {
    $("task-error").textContent = "Could not update the task. Try again.";
  }
}

async function deleteTask(task) {
  if (!confirm(`Delete "${task.title}"?`)) return;
  try {
    await deleteDoc(doc(db, "users", currentUser.uid, "tasks", task.id));
  } catch (_) {
    $("task-error").textContent = "Could not delete the task. Try again.";
  }
}

document.querySelectorAll(".filters button").forEach((btn) => {
  btn.addEventListener("click", () => {
    filter = btn.dataset.filter;
    render();
  });
});

// ---------- rendering ----------
function formatDate(iso) {
  const [y, m, d] = iso.split("-").map(Number);
  return new Date(y, m - 1, d).toLocaleDateString(undefined, {
    day: "numeric", month: "short", year: "numeric",
  });
}
function todayISO() {
  const n = new Date();
  const pad = (v) => String(v).padStart(2, "0");
  return `${n.getFullYear()}-${pad(n.getMonth() + 1)}-${pad(n.getDate())}`;
}
function millis(task) {
  return task.createdAt && task.createdAt.toMillis ? task.createdAt.toMillis() : Date.now();
}
// pending pehle, phir due date (jiski date nahi wo last), phir naya task upar
function sortTasks(list) {
  return [...list].sort((a, b) => {
    if ((a.status === "completed") !== (b.status === "completed")) return a.status === "completed" ? 1 : -1;
    if (a.dueDate !== b.dueDate) {
      if (!a.dueDate) return 1;
      if (!b.dueDate) return -1;
      return a.dueDate < b.dueDate ? -1 : 1;
    }
    return millis(b) - millis(a);
  });
}

function render() {
  const pending = tasks.filter((t) => t.status === "pending").length;
  $("count-all").textContent = tasks.length;
  $("count-pending").textContent = pending;
  $("count-completed").textContent = tasks.length - pending;

  document.querySelectorAll(".filters button").forEach((b) => {
    b.setAttribute("aria-selected", b.dataset.filter === filter);
  });

  const visible = sortTasks(tasks.filter((t) => filter === "all" || t.status === filter));
  const list = $("task-list");
  list.replaceChildren();

  const empty = $("empty");
  if (visible.length === 0) {
    empty.hidden = false;
    empty.textContent =
      tasks.length === 0 ? "No tasks yet. Add your first one above."
      : filter === "pending" ? "Nothing pending. Nice work."
      : "No completed tasks yet.";
  } else {
    empty.hidden = true;
  }

  const today = todayISO();
  for (const task of visible) {
    const done = task.status === "completed";
    const li = el("li", "task" + (done ? " done" : ""));

    const tick = el("label", "tick");
    const box = document.createElement("input");
    box.type = "checkbox";
    box.checked = done;
    box.setAttribute("aria-label", `Mark "${task.title}" as ${done ? "pending" : "completed"}`);
    box.addEventListener("change", () => toggleTask(task));
    tick.append(box, el("span"));

    const body = el("div", "body");
    body.append(el("span", "title", task.title));
    const meta = el("div", "meta");
    meta.append(el("span", "badge", done ? "Completed" : "Pending"));
    if (task.subject) meta.append(el("span", "", task.subject));
    if (task.dueDate) {
      const late = !done && task.dueDate < today;
      meta.append(el("span", late ? "overdue" : "", (late ? "Overdue: " : "Due ") + formatDate(task.dueDate)));
    }
    body.append(meta);

    const del = el("button", "delete", "Delete");
    del.type = "button";
    del.addEventListener("click", () => deleteTask(task));

    li.append(tick, body, del);
    list.append(li);
  }
}
